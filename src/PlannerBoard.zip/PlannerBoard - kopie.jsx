import React, { useState, useEffect } from "react";
import {
  getShiftCountPerMedewerker,
  importeerBeschikbaarheidKnop,
  importeerLoonkostenKnop,
} from "./utils/plannerHelpers";
import { dagMap } from "./utils/dagen";
import { exportToPDF } from "./utils/exportToPDF";

const dagen = ["ma", "di", "wo", "do", "vr", "za", "zo"];
const shifts = [1, 2];

export default function PlannerBoard({ beschikbaarheid: beschikbaarheidProp, planning, setPlanning, onTotalLoonkostenChange }) {
  const [medewerkers, setMedewerkers] = useState(() => {
    try {
      const saved = localStorage.getItem("medewerkers");
      const parsed = saved ? JSON.parse(saved) : [];
      return Array.isArray(parsed) ? parsed.filter((m) => m && typeof m === "object" && m.naam) : [];
    } catch {
      return [];
    }
  });

  const [beschikbaarheid, setLocalBeschikbaarheid] = useState(() => {
    try {
      const saved = localStorage.getItem("beschikbaarheid");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    if (beschikbaarheidProp && Object.keys(beschikbaarheidProp).length > 0) {
      setLocalBeschikbaarheid(beschikbaarheidProp);
      localStorage.setItem("beschikbaarheid", JSON.stringify(beschikbaarheidProp));
    }
  }, [beschikbaarheidProp]);

  const [popup, setPopup] = useState(null);
  const shiftCountPerMedewerker = getShiftCountPerMedewerker(planning);

  const [loonkostenPerUur, setLoonkostenPerUur] = useState(() => {
    try {
      const saved = localStorage.getItem("loonkosten");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const gestructureerdeUpdate = (prev, popup, functie, soort) => {
    return {
      ...prev,
      [popup.medewerker]: {
        ...prev[popup.medewerker],
        [popup.dag]: {
          ...prev[popup.medewerker]?.[popup.dag],
          [popup.shift]: { functie, soort },
        },
      },
    };
  };

  const updatePlanning = (functie, soort) => {
    if (popup) {
      setPlanning((prev) => {
        const nieuwePlanning = gestructureerdeUpdate(prev, popup, functie, soort);
        localStorage.setItem("planning", JSON.stringify(nieuwePlanning));
        return nieuwePlanning;
      });
      setPopup(null);
    }
  };

  useEffect(() => {
    let totaal = 0;
    medewerkers.forEach((m) => {
      dagen.forEach((dag) => {
        shifts.forEach((shift) => {
          const entry = planning[m.naam]?.[dag]?.[shift];
          if (entry) {
            const uren = entry.soort === "standby" ? 4 : 6;
            const leeftijd = typeof m.leeftijd === 'number' ? m.leeftijd : 18;
            const uurloon = loonkostenPerUur[leeftijd] ?? 15;
            totaal += uren * uurloon;
          }
        });
      });
    });

    if (typeof onTotalLoonkostenChange === 'function') {
      onTotalLoonkostenChange(totaal);
    }
  }, [planning, medewerkers]);

  return (
    <div className="p-4 bg-gray-100">
      <div className="overflow-x-auto mb-4">
        <table className="text-xs border-collapse w-full bg-white shadow">
          <thead>
            <tr>
              <th className="border px-2 py-1 w-60 text-left">Type</th>
              {dagen.map((dag) =>
                shifts.map((shift) => (
                  <th key={`${dag}-${shift}`} className="border px-2 py-1 text-center">
                    {dagMap[dag]} shift {shift}
                  </th>
                ))
              )}
            </tr>
          </thead>
          <tbody>
            {["Bereiders", "Voorbereiders", "Scheppers", "Kosten"].map((type) => (
              <tr key={type}>
                <td className="border px-2 py-1 font-semibold">{type}</td>
                {dagen.map((dag) =>
                  shifts.map((shift) => {
                    let value = 0;
                    if (type === "Kosten") {
                      value = medewerkers.reduce((totaal, m) => {
                        const entry = planning[m.naam]?.[dag]?.[shift];
                        if (!entry) return totaal;
                        const uren = entry.soort === "standby" ? 4 : 6;
                        const leeftijd = typeof m.leeftijd === "number" ? m.leeftijd : 18;
                        const uurloon = loonkostenPerUur[leeftijd] ?? 15;
                        return totaal + uren * uurloon;
                      }, 0);
                    } else {
                      const functieMap = {
                        Bereiders: "ijsbereider",
                        Voorbereiders: "ijsvoorbereider",
                        Scheppers: "schepper",
                      };
                      const functie = functieMap[type];
                      value = medewerkers.filter((m) => planning[m.naam]?.[dag]?.[shift]?.functie === functie).length;
                    }
                    return (
                      <td key={`${type}-${dag}-${shift}`} className="border px-2 py-1 text-center">
                        {type === "Kosten" ? `€ ${Math.round(value)}` : value}
                      </td>
                    );
                  })
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex gap-2 items-center mb-4">
        {importeerBeschikbaarheidKnop(setLocalBeschikbaarheid, setMedewerkers)}
        {importeerLoonkostenKnop(setLoonkostenPerUur)}
        <button
          onClick={() =>
            exportToPDF({
              medewerkers,
              planning,
              beschikbaarheid,
              loonkostenPerUur,
              shiftCountPerMedewerker,
            })
          }
          className="bg-red-600 text-white px-4 py-2 rounded shadow"
        >
          Exporteer naar PDF
        </button>
      </div>

      {medewerkers.length === 0 && (
        <p className="text-gray-600">Nog geen medewerkers geladen. Importeer beschikbaarheid om te starten.</p>
      )}

      {medewerkers.length > 0 && (
        <table className="table-fixed border w-full bg-white text-xs font-sans">
          <thead>
            <tr>
              <th className="border px-4 py-2 text-left w-60">Naam</th>
              {dagen.map((dag) =>
                shifts.map((shift) => (
                  <th key={`${dag}-${shift}`} className="border px-2 py-1 text-center">
                    {dag} {shift}
                  </th>
                ))
              )}
            </tr>
          </thead>
          <tbody>
            {medewerkers.map((m) => (
              <tr key={m.naam}>
                {(() => {
                  const count = shiftCountPerMedewerker[m.naam] || 0;
                  const max = m.maxShifts ?? "?";
                  const leeftijd = m.leeftijd ?? "?";
                  const bgClass =
                    count > max ? "bg-red-200" : count < max ? "bg-yellow-200" : "";
                  return (
                    <td
                      className={`border px-4 py-2 text-left whitespace-nowrap w-60 font-bold ${bgClass}`}
                      title={m.opmerking || ""}
                    >
                      {m.naam.split(" ").map((part, i) =>
                        i === 0 ? part : part.charAt(0).toUpperCase() + part.slice(1)
                      ).join(" ")} [{leeftijd}] ({count}/{max})
                    </td>
                  );
                })()}
                {dagen.map((dag) =>
                  shifts.map((shift) => {
                    const naamKey = m.naam?.toLowerCase();
                    const entry = planning[m.naam]?.[dag]?.[shift];
                    const beschikbaar = beschikbaarheid?.[naamKey]?.[dagMap[dag]]?.[shift];
                    let text = "";
                    let bgColor = "#ffffff";

                    if (entry) {
                      const colorMapping = {
                        ijsbereider: { vast: "#1E3A8A", standby: "#2563EB", laat: "#93C5FD" },
                        ijsvoorbereider: { vast: "#065F46", standby: "#059669", laat: "#6EE7B7" },
                        schepper: { vast: "#334155", standby: "#64748B", laat: "#CBD5E1" },
                      };
                      bgColor = colorMapping[entry.functie]?.[entry.soort] || "#ffffff";
                      const labelMap = {
                        schepper: { vast: "schep", standby: "schep(s)", laat: "schep(l)" },
                        ijsbereider: { vast: "bereider", standby: "bereider(s)", laat: "bereider(l)" },
                        ijsvoorbereider: { vast: "prep", standby: "prep(s)", laat: "prep(l)" },
                      };
                      text = labelMap[entry.functie]?.[entry.soort] || `${entry.functie} (${entry.soort})`;
                    } else if (beschikbaar) {
                      text = "";
                      bgColor = "#90EE90"; // Lichtgroen voor beschikbaarheid
                    }

                    return (
                      <td
                        key={`${m.naam}-${dag}-${shift}`}
                        title={`Shift ${shift} op ${dagMap[dag]}`}
                        className="border text-center cursor-pointer"
                        onClick={() => {
                          const entry = planning[m.naam]?.[dag]?.[shift];
                          if (entry) {
                            setPlanning((prev) => {
                              const nieuw = { ...prev };
                              delete nieuw[m.naam][dag][shift];
                              if (Object.keys(nieuw[m.naam][dag]).length === 0) delete nieuw[m.naam][dag];
                              if (Object.keys(nieuw[m.naam]).length === 0) delete nieuw[m.naam];
                              localStorage.setItem("planning", JSON.stringify(nieuw));
                              return nieuw;
                            });
                          } else {
                            setPopup({ medewerker: m.naam, dag, shift });
                          }
                        }}
                        style={{
                          backgroundColor: bgColor,
                          color:
                            (entry?.functie === "ijsbereider" && entry?.soort === "vast") ? "white" :
                            (entry?.functie === "ijsbereider" && entry?.soort === "standby") ? "yellow" :
                            (entry?.functie === "schepper" && entry?.soort === "vast") ? "white" :
                            (entry?.functie === "schepper" && entry?.soort === "standby") ? "yellow" :
                            "initial",
                          fontWeight: "bold",
                        }}
                      >
                        {text}
                      </td>
                    );
                  })
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {popup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-4 rounded shadow-md w-[400px]">
            <h2 className="font-bold mb-4 text-center">
              {popup.medewerker} - {popup.dag} Shift {popup.shift}
            </h2>
            <div className="grid grid-cols-3 gap-2">
              {["ijsbereider", "ijsvoorbereider", "schepper"].map((functie) =>
                ["vast", "standby", "laat"].map((soort) => {
                  let kleur = "";
                  let label = "";

                  if (functie === "ijsbereider") {
                    kleur = soort === "vast" ? "bg-blue-900 text-white" :
                            soort === "standby" ? "bg-blue-600 text-white" :
                            "bg-blue-300 text-black";
                    label = soort === "vast" ? "bereider" :
                            soort === "standby" ? "⏱️ bereider" : "🌙 bereider";
                  }

                  if (functie === "ijsvoorbereider") {
                    kleur = soort === "vast" ? "bg-green-900 text-white" :
                            soort === "standby" ? "bg-green-600 text-white" :
                            "bg-green-300 text-black";
                    label = soort === "vast" ? "prep" :
                            soort === "standby" ? "⏱️ prep" : "🌙 prep";
                  }

                  if (functie === "schepper") {
                    kleur = soort === "vast" ? "bg-slate-700 text-white" :
                            soort === "standby" ? "bg-slate-500 text-white" :
                            "bg-slate-300 text-black";
                    label = soort === "vast" ? "schep" :
                            soort === "standby" ? "⏱️ schep" : "🌙 schep";
                  }

                  return (
                    <button
                      key={`${functie}-${soort}`}
                      className={`${kleur} px-3 py-2 rounded font-medium text-sm`}
                      onClick={() => updatePlanning(functie, soort)}
                    >
                      {label}
                    </button>
                  );
                })
              )}
            </div>
            <div className="mt-4 text-center">
              <button onClick={() => setPopup(null)} className="text-gray-600 text-sm underline">
                Annuleren
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
