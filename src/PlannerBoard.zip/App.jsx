import { useState, useEffect } from "react";
import PlannerBoard from "./PlannerBoard";

export default function App() {
  const [planning, setPlanning] = useState(() => {
    const opgeslagen = localStorage.getItem("planning");
    return opgeslagen ? JSON.parse(opgeslagen) : {};
  });

  const [beschikbaarheid, setBeschikbaarheid] = useState({});
  const [medewerkers, setMedewerkers] = useState([]);
  const [totaleLoonkosten, setTotaleLoonkosten] = useState(0); // ✅ Toegevoegd

  useEffect(() => {
    const b = localStorage.getItem("beschikbaarheid");
    if (b) setBeschikbaarheid(JSON.parse(b));
    const m = localStorage.getItem("medewerkers");
    if (m) setMedewerkers(JSON.parse(m));
  }, []);

  return (
    <div className="p-4">
      <div className="text-right text-lg font-bold mb-2">
        Totale loonkosten: €{totaleLoonkosten.toFixed(2)}
      </div>

      <PlannerBoard
        medewerkers={medewerkers}
        beschikbaarheid={beschikbaarheid}
        planning={planning}
        setPlanning={setPlanning}
        onTotalLoonkostenChange={setTotaleLoonkosten}
      />
    </div>
  );
}
