
// Bestand: pdfExport.js
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

const shifts = [1, 2];
import { dagMap } from "./utils/dagen";

function buildPlanningTable(doc, medewerkers, dagen, planning, beschikbaarheid) {
  const tableColumn = ["Naam", ...dagen.flatMap((dag) => shifts.map((shift) => `${dag} ${shift}`))];
  const body = medewerkers.map((m) => {
    const naamKey = m.naam.toLowerCase();
    const count = Object.values(planning[m.naam] || {}).flatMap(s => Object.values(s)).length;
    const max = m.maxShifts ?? "?";
    const leeftijd = m.leeftijd ?? "?";
    const row = { Naam: `${m.naam} [${leeftijd}] (${count}/${max})` };

    dagen.forEach((dag) => {
      shifts.forEach((shift) => {
        const key = `${dag} ${shift}`;
        const entry = planning[m.naam]?.[dag]?.[shift];
        const beschikbaar = beschikbaarheid?.[naamKey]?.[dagMap[dag]]?.[shift];
        if (entry) {
          if (entry.functie === "schepper") row[key] = entry.soort === "vast" ? "schep" : "schep(s)";
          else if (entry.functie === "ijsbereider") row[key] = entry.soort === "vast" ? "bereider" : "bereider(s)";
          else if (entry.functie === "ijsvoorbereider") row[key] = entry.soort === "vast" ? "prep" : "prep(s)";
          else row[key] = `${entry.functie} (${entry.soort})`;
        } else if (beschikbaar) {
          row[key] = "✓";
        } else {
          row[key] = "";
        }
      });
    });

    return row;
  });

  autoTable(doc, {
    columns: tableColumn.map((key) => ({ header: key, dataKey: key })),
    body,
    startY: 20,
    styles: {
      fontSize: 8,
      halign: "center",
      valign: "middle",
      cellPadding: 2,
      lineWidth: 0.1,
      lineColor: [0, 0, 0],
    },
    headStyles: {
      fillColor: [41, 128, 185],
      textColor: [255, 255, 255],
      fontStyle: "bold",
    },
    didParseCell(data) {
      const val = typeof data.cell.raw === "string" ? data.cell.raw.toLowerCase().trim() : "";
      if (val === "bereider") data.cell.styles.fillColor = [30, 58, 138];
      else if (val === "bereider(s)") data.cell.styles.fillColor = [96, 165, 250];
      else if (val === "prep") data.cell.styles.fillColor = [191, 219, 254];
      else if (val === "prep(s)") data.cell.styles.fillColor = [219, 234, 254];
      else if (val === "schep") data.cell.styles.fillColor = [250, 204, 21];
      else if (val === "schep(s)") data.cell.styles.fillColor = [254, 240, 138];
      else if (val === "✓") data.cell.styles.fillColor = [144, 238, 144];
    },
  });
}

function buildTotalTable(doc, medewerkers, dagen, planning, salarissenPerLeeftijd) {
  doc.addPage();

  const loonkostenPerDagPerShift = {};
  const aantallen = {
    ijsbereider: {},
    ijsvoorbereider: {},
    schepper: {},
  };

  dagen.forEach((dag) => {
    shifts.forEach((shift) => {
      let totaal = 0;
      medewerkers.forEach(({ naam, leeftijd }) => {
        const entry = planning[naam]?.[dag]?.[shift];
        if (entry) {
          const uren = entry.soort === "standby" ? 4 : 6;
          const uurloon = salarissenPerLeeftijd[leeftijd] || 0;
          totaal += uren * uurloon;

          if (aantallen[entry.functie]) {
            aantallen[entry.functie][`${dag} shift ${shift}`] = (aantallen[entry.functie][`${dag} shift ${shift}`] || 0) + 1;
          }
        }
      });
      loonkostenPerDagPerShift[`${dag} shift ${shift}`] = `€ ${Math.round(totaal)}`;
    });
  });

  const kolommen = ["Dag", ...dagen.flatMap((dag) => shifts.map((s) => `${dag} shift ${s}`))];

  const body = [
    ["Loonkosten", ...kolommen.slice(1).map((key) => loonkostenPerDagPerShift[key] || "€ 0")],
    ["Bereiders", ...kolommen.slice(1).map((key) => aantallen.ijsbereider[key] || 0)],
    ["Voorbereiders", ...kolommen.slice(1).map((key) => aantallen.ijsvoorbereider[key] || 0)],
    ["Scheppers", ...kolommen.slice(1).map((key) => aantallen.schepper[key] || 0)],
  ];

  autoTable(doc, {
    head: [kolommen],
    body,
    startY: 20,
    styles: {
      fontSize: 8,
      halign: 'center',
      valign: 'middle',
      cellPadding: 2,
      lineWidth: 0.1,
      lineColor: [0, 0, 0]
    },
    headStyles: { fillColor: [100, 149, 237], textColor: 255 },
    columnStyles: { 0: { fontStyle: 'bold', halign: 'left' } }
  });
}

function addLegenda(doc) {
  const startY = doc.lastAutoTable.finalY + 10;
  doc.setFontSize(8);
  doc.text("Legenda:", 40, startY);

  const kleuren = [
    { kleur: [30, 58, 138], label: "Bereider" },
    { kleur: [96, 165, 250], label: "Bereider(s)" },
    { kleur: [191, 219, 254], label: "Prep" },
    { kleur: [219, 234, 254], label: "Prep(s)" },
    { kleur: [250, 204, 21], label: "Schep" },
    { kleur: [254, 240, 138], label: "Schep(s)" },
    { kleur: [144, 238, 144], label: "Beschikbaar" },
  ];

  kleuren.forEach((item, index) => {
    const y = startY + 10 + index * 7;
    doc.setFillColor(...item.kleur);
    doc.rect(40, y - 5, 5, 5, "F");
    doc.text(item.label, 48, y);
  });
}

export function exporteerPDF(medewerkers, dagen, planning, beschikbaarheid, salarissenPerLeeftijd) {
  const doc = new jsPDF({ orientation: "landscape", format: "a4" });
  buildPlanningTable(doc, medewerkers, dagen, planning, beschikbaarheid);
  buildTotalTable(doc, medewerkers, dagen, planning, salarissenPerLeeftijd);
  addLegenda(doc);


  const loonkostenPerUur = { 16: 6.5, 17: 7, 18: 8, 19: 9, 20: 10, 21: 11, 22: 12, 23: 13, 24: 14, 25: 15 };
  let totaalLoonkosten = 0;

  medewerkers.forEach((m) => {
    const uurloon = loonkostenPerUur[m.leeftijd] ?? 15;
    dagen.forEach((dag) => {
      shifts.forEach((shift) => {
        const entry = planning[m.naam]?.[dag]?.[shift];
        if (entry) {
          const uren = entry.soort === "standby" ? 4 : 6;
          totaalLoonkosten += uren * uurloon;
        }
      });
    });
  });

  const laatsteY = doc.lastAutoTable.finalY + 10;
  doc.setFontSize(12);
  doc.setTextColor(40);
  doc.setFont(undefined, 'bold');
  doc.text(`Totale loonkosten: €${totaalLoonkosten.toFixed(2)}`, 14, laatsteY + 6);






  doc.save("planning_export.pdf");
}
