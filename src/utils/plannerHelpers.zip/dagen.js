// Bestand: utils/dagen.js

export const dagMap = {
    ma: "maandag",
    di: "dinsdag",
    wo: "woensdag",
    do: "donderdag",
    vr: "vrijdag",
    za: "zaterdag",
    zo: "zondag",
  };
  
  export const dagen = ["ma", "di", "wo", "do", "vr", "za", "zo"];
  export const shifts = [1, 2];
  