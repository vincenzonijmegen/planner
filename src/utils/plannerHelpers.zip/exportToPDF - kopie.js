import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { dagMap } from "./dagen";

const dagen = ["ma", "di", "wo", "do", "vr", "za", "zo"];
const shifts = [1, 2];

const buildPdfBody = (medewerkers, planning, beschikbaarheid, shiftCountPerMedewerker) => {
  const body = [];

  medewerkers.forEach((m) => {
    const naam = m.naam;
    const count = shiftCountPerMedewerker[naam] || 0;
    const max = m.maxShifts ?? "?";
    const leeftijd = m.leeftijd ?? "?";

    const row = {
      Naam: `${naam.split(" ").map((part, i) =>
        i === 0 ? part : part.charAt(0).toUpperCase() + part.slice(1)
      ).join(" ")} [${leeftijd}] (${count}/${max})`
    };

    dagen.forEach((dag) => {
      shifts.forEach((shift) => {
        const key = `${dag} ${shift}`;
        const entry = planning[naam]?.[dag]?.[shift];
        const naamKey = naam?.toLowerCase();
        const beschikbaar = beschikbaarheid?.[naamKey]?.[dagMap[dag]]?.[shift];

        if (entry) {
          const labelMap = {
            schepper: { vast: "schep", standby: "schep(s)", laat: "schep(l)" },
            ijsbereider: { vast: "bereider", standby: "bereider(s)", laat: "bereider(l)" },
            ijsvoorbereider: { vast: "prep", standby: "prep(s)", laat: "prep(l)" },
          };
          row[key] = labelMap[entry.functie]?.[entry.soort] || `${entry.functie} (${entry.soort})`;
        } else if (beschikbaar) {
          row[key] = "✓";
        } else {
          row[key] = "";
        }
      });
    });

    body.push(row);
  });

  return body;
};

export const exportToPDF = ({ medewerkers, planning, beschikbaarheid, loonkostenPerUur, shiftCountPerMedewerker }) => {
  const doc = new jsPDF({ orientation: "landscape", format: "a4" });
  const vandaag = new Date();
const datumStr = vandaag.toLocaleDateString("nl-NL");
const weekNr = getWeekNumber(vandaag);
doc.setFontSize(16);
doc.text(`Beschikbaarheid ijssalon Vincenzo – versie (${datumStr})`, 14, 12);
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;

  const tableColumn = ["Naam", ...dagen.flatMap((dag) => shifts.map((shift) => `${dag} ${shift}`))];
  const body = buildPdfBody(medewerkers, planning, beschikbaarheid, shiftCountPerMedewerker);

  autoTable(doc, {
    startY: 20,
    tableWidth: pageWidth - margin,
    columns: tableColumn.map((key) => ({ header: key, dataKey: key })),
    body,
    styles: {
      fontSize: 8,
      cellPadding: 2,
      halign: "center",
      valign: "middle",
      lineWidth: 0.1,
      lineColor: [0, 0, 0],
    },
    headStyles: {
      fillColor: [41, 128, 185],
      textColor: [255, 255, 255],
      fontStyle: "bold",
    },
    columnStyles: {
      Naam: { halign: "left", cellWidth: 60 },
    },
    didParseCell(data) {
        const val = typeof data.cell.raw === "string" ? data.cell.raw.toLowerCase().trim() : "";
      
        const kleuren = {
          "bereider": [30, 58, 138],
          "bereider(s)": [96, 165, 250],
          "bereider(l)": [167, 139, 250],
          "prep": [191, 219, 254],
          "prep(s)": [219, 234, 254],
          "prep(l)": [196, 181, 253],
          "schep": [250, 204, 21],
          "schep(s)": [254, 240, 138],
          "schep(l)": [243, 244, 246],
          "✓": [144, 238, 144],
        };
      
        if (kleuren[val]) {
          data.cell.styles.fillColor = kleuren[val];
      
          // ✅ Donkere achtergronden → witte tekst
          const donkereWaarden = ["bereider", "bereider(l)"];
      
          if (donkereWaarden.includes(val)) {
            data.cell.styles.textColor = [255, 255, 255]; // wit
          }
      
          // ✅ "✓" → tekstkleur = zelfde als achtergrond = onzichtbaar
          else if (val === "✓") {
            data.cell.styles.textColor = kleuren[val];
          }
      
          // ✅ Alles met lichte achtergrond → zwarte tekst
          else {
            data.cell.styles.textColor = [0, 0, 0];
          }
        }
      }
      
  });

  addLoonkostenTabel(doc, medewerkers, planning, loonkostenPerUur);
  let laatsteY = addLegenda(doc);

  // check voor pagina-overloop
if (laatsteY > doc.internal.pageSize.getHeight() - 20) {
    doc.addPage();
    laatsteY = 20;}

  // ✅ Totaal loonkosten berekenen
  const totaalLoonkosten = medewerkers.reduce((totaal, m) => {
    const uurloon = loonkostenPerUur[m.leeftijd] ?? 15;
    return totaal + dagen.reduce((dagTotaal, dag) => {
      return dagTotaal + shifts.reduce((shiftTotaal, shift) => {
        const entry = planning[m.naam]?.[dag]?.[shift];
        if (!entry) return shiftTotaal;
        const uren = entry.soort === "standby" ? 4 : 6;
        return shiftTotaal + uren * uurloon;
      }, 0);
    }, 0);
  }, 0);

  doc.setFontSize(12);
  doc.setTextColor(40);
  doc.setFont(undefined, "bold");
  doc.text(`Totale loonkosten deze week: €${totaalLoonkosten.toFixed(2)}`, 14, laatsteY);
  doc.save("planning_export.pdf");
};

function addLoonkostenTabel(doc, medewerkers, planning, loonkostenPerUur) {
  const kolommen = ["Dag", ...dagen.flatMap(dag => shifts.map(s => `${dag} shift ${s}`))];

  const loonkostenPerShift = {};
  const telling = {
    ijsbereider: {},
    ijsvoorbereider: {},
    schepper: {}
  };

  dagen.forEach(dag => {
    shifts.forEach(shift => {
      const key = `${dag} shift ${shift}`;
      loonkostenPerShift[key] = 0;
      telling.ijsbereider[key] = 0;
      telling.ijsvoorbereider[key] = 0;
      telling.schepper[key] = 0;

      medewerkers.forEach(m => {
        const entry = planning[m.naam]?.[dag]?.[shift];
        if (entry) {
          const uren = entry.soort === "standby" ? 4 : 6;
          const uurloon = loonkostenPerUur[m.leeftijd] ?? 15;
          loonkostenPerShift[key] += uren * uurloon;
          if (telling[entry.functie]) telling[entry.functie][key]++;
        }
      });
    });
  });

  const body = [
    ["Loonkosten", ...kolommen.slice(1).map(key => `€ ${Math.round(loonkostenPerShift[key] || 0)}`)],
    ["Bereiders", ...kolommen.slice(1).map(key => telling.ijsbereider[key] || 0)],
    ["Voorbereiders", ...kolommen.slice(1).map(key => telling.ijsvoorbereider[key] || 0)],
    ["Scheppers", ...kolommen.slice(1).map(key => telling.schepper[key] || 0)],
  ];

  const startY = doc.lastAutoTable.finalY + 20;
  autoTable(doc, {
    startY,
    head: [kolommen],
    body,
    styles: {
      fontSize: 8,
      halign: 'center',
      valign: 'middle',
      cellPadding: 2,
      lineWidth: 0.1,
      lineColor: [0, 0, 0],
    },
    headStyles: {
      fillColor: [100, 149, 237],
      textColor: 255,
    },
    columnStyles: { 0: { fontStyle: 'bold', halign: 'left' } },
  });
}

function addLegenda(doc) {
  const functies = [
    [
      { kleur: [30, 58, 138], label: "Bereider" },
      { kleur: [96, 165, 250], label: "Bereider(s)" },
      { kleur: [167, 139, 250], label: "Bereider(l)" },
    ],
    [
      { kleur: [191, 219, 254], label: "Prep" },
      { kleur: [219, 234, 254], label: "Prep(s)" },
      { kleur: [196, 181, 253], label: "Prep(l)" },
    ],
    [
      { kleur: [250, 204, 21], label: "Schep" },
      { kleur: [254, 240, 138], label: "Schep(s)" },
      { kleur: [243, 244, 246], label: "Schep(l)" },
    ],
  ];

  const beschikbaar = { kleur: [144, 238, 144], label: "Beschikbaar" };

  const kolombreedte = 70;
  const rijenPerKolom = functies[0].length;
  const totaalHoogte = rijenPerKolom * 7 + 10 + 10; // legenda + kopje + beschikbaar

  let startY = doc.lastAutoTable?.finalY + 10 || 160;

  // ✅ Als niet alles past, voeg een pagina toe
  const ruimteNodig = startY + totaalHoogte;
  if (ruimteNodig > doc.internal.pageSize.getHeight() - 20) {
    doc.addPage();
    startY = 20;
  }

  doc.setFontSize(8);
  doc.text("Legenda:", 40, startY);

  const kolomX = [40, 40 + kolombreedte, 40 + kolombreedte * 2];

  for (let i = 0; i < 3; i++) {
    functies[i].forEach((item, j) => {
      const x = kolomX[i];
      const y = startY + 10 + j * 7;
      doc.setFillColor(...item.kleur);
      doc.rect(x, y - 5, 5, 5, "F");
      doc.text(item.label, x + 8, y);
    });
  }

  const beschikbaarY = startY + 10 + rijenPerKolom * 7 + 5;
  doc.setFillColor(...beschikbaar.kleur);
  doc.rect(40, beschikbaarY - 5, 5, 5, "F");
  doc.text(beschikbaar.label, 48, beschikbaarY);

  return beschikbaarY + 10; // voor volgende blok
}

  
  function getWeekNumber(date) {
    const temp = new Date(date.getTime());
    temp.setHours(0, 0, 0, 0);
    temp.setDate(temp.getDate() + 3 - ((temp.getDay() + 6) % 7));
    const week1 = new Date(temp.getFullYear(), 0, 4);
    return 1 + Math.round(((temp.getTime() - week1.getTime()) / 86400000 - 3 + ((week1.getDay() + 6) % 7)) / 7);
  }
  
 

